document.querySelector('nav ul li a').addEventListener('click', function(event) {
 event.preventDefault();
 var sectionId = this.getAttribute('href');
 var section = document.querySelector(sectionId);
 section.scrollIntoView({ behavior: 'smooth' });
});

